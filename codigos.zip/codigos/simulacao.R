
setwd("C:~\\codigos")

source("funcoes.r")

#----------------------------------------------------------------
R <- 10000

para <- c(0.5,0.1,-3)

#----------------------------------------------------------------
n <- 50 # 100, 150 e 200
m <- 0.0075 # (10% de censura), 0,052 (30% de censura) e 0.12 (50% de censura)
#----------------------------------------------------------------
 
sim <- simula.residual(R=R,n=n,para=para,x1=runif(n,0,1),m=m)

pdf("Q_cs_50_10.pdf", width=8.27, height=8.27)

par(mar=c(4,5,1,1))
plot(sim$med.CS ,quantile(sim$med.CS,p=ppoints(n)), main="", 
     xlab="Índice",ylab="Residuos de Cox-Snell",pch=15,cex.lab=2.5,
     xlim=c(0,3),ylim=c(0,3),cex.axis=1.5)

points(seq(0,3,10e-5),seq(0,3,10e-5),type = "l",lwd=3)

dev.off()

pdf("Q_csm_50_10.pdf", width=8.27, height=8.27)
plot(sim$med.CSm ,quantile(sim$med.CSm,p=ppoints(n)), main="", 
     xlab="Índice",ylab="Residuos modificados de Cox-Snell",pch=15,
     cex.lab=2,xlim=c(0,3),ylim=c(0,3),cex.axis =2)
points(seq(0,3,10e-5),seq(0,3,10e-5),type = "l")
dev.off()

pdf("Q_m_50_10.pdf", width=8.27, height=8.27)
qqnorm(sim$med.M, main="", xlab="Índice",ylab="Residuos Martingale",pch=15,cex.lab=1.55,cex.axis = 1.5)
points(seq(-3,3,10e-5),seq(-3,3,10e-5),type = "l")
dev.off()

pdf("Q_d_50_10.pdf", width=8.27, height=8.27)
qqnorm(sim$med.Dev,xlim=c(-3,3),ylim=c(-3,3),ylab="Residuos Deviance", xlab="Índice",main="",pch=15,cex.lab=1.55,cex.axis = 1.5)
points(seq(-3,3,10e-5),seq(-3,3,10e-5),type = "l")
dev.off()

pdf("Q_nm_50_10.pdf", width=8.27, height=8.27)
qqnorm(sim$med.NMSP,xlim=c(-3,3),ylim=c(-3,3),ylab="Residuos NMSP", xlab="Índice",main="",pch=15,cex.lab=1.55,cex.axis = 1.5)
points(seq(-3,3,10e-5),seq(-3,3,10e-5),type = "l")
dev.off()

pdf("Q_nr_50_10.pdf", width=8.27, height=8.27)
qqnorm(sim$med.NRSP,xlim=c(-3,3),ylim=c(-3,3),ylab="Residuos NRSP", xlab="Índice",main="",pch=15,cex.lab=1.55,cex.axis = 1.5)
points(seq(-3,3,10e-5),seq(-3,3,10e-5),type = "l")
dev.off()

pdf("Q_q_50_10.pdf", width=8.27, height=8.27)
qqnorm(sim$med.Quant,xlim=c(-3,3),ylim=c(-3,3),ylab="Residuos Quant?licos", xlab="Índice",main="",pch=15,cex.lab=1.55,cex.axis = 1.5)
points(seq(-3,3,10e-5),seq(-3,3,10e-5),type = "l")
dev.off()

#----------------------------------------------------------------

