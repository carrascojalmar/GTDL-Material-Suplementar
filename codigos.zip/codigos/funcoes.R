#------------------------------
# Librarias

require(bbmle)
require(dplyr)
require(fBasics)
require(SMPracticals)

#------------------------------
# Funções

qGTDL.1 <- function(para){
  lambda <- para[1]
  alpha <- para[2]
  gamma <- para[3]
  
  u <- runif(1)
  t <- (1/alpha)*(log((1+exp(gamma))*(1-u)^(-alpha/lambda)-1)-gamma)
  return(t)
}

qGTDL.2 <- function(para,p){
  lambda <- para[1]
  alpha <- para[2]
  gamma <- para[3]
  
  u <- runif(1,min=0,max=(1-p))
  t <- (1/alpha)*(log((1+exp(gamma))*(1-u)^(-alpha/lambda)-1)-gamma)
  return(t)
}

rGTDL <- function(n,para,x1,m){
  if(para[2]>0){
    amostra <- matrix(NA,ncol=3,nrow=n)
    for(i in 1:n){
      vPara1 <- c(para[1],para[2],x1[i]*para[3]) 
      T  <-  qGTDL.1(para=vPara1)
      C  <-  rexp(1,m)
      if(m==0){t <- T}
      else{t <- min(T,C)
      }
      amostra[i,1] <- t  
      if(t==T){amostra[i,2] <-1}else{amostra[i,2] <-0}
      amostra[i,3] <- x1[i] 
    }
    return(amostra)
  }
  if(para[2]<0){
    amostra <- matrix(NA,ncol=3,nrow=n)
    for(i in 1:n){
      fun1 <- 1+exp(x1[i]*para[3])
      p <- fun1^(para[1]/para[2])
      M <- rbinom(1,1,1-p)
      if(M==0){
        T <- Inf
      }else{
        vPara2 <- c(para[1],para[2],x1[i]*para[3]) 
        T <- qGTDL.2(para=vPara2,p=p)
      }
      C <- rexp(1,m)
      if(m==0){t <- T}
      else{t <- min(T,C)
      }
      amostra[i,1] <- t 
      if(t==T){amostra[i,2] <-1}else{amostra[i,2] <-0}
      amostra[i,3] <- x1[i] 
    }
    return(amostra)
  }
}

l.GTDL <- function(lambda,alpha,beta1,dados) {
  #---------------------
  t <- dados[,1]
  d <- dados[,2]
  x1 <- dados[,3]
  #---------------------
  eta <- t*alpha+beta1*x1
  risco <- lambda*exp(eta)/(1+exp(eta))	
  sobrev <- ((1+exp(beta1*x1))/(1+exp(eta)))^(lambda/alpha)	
  #-------------------------
  ll <- sum(d*log(risco))+sum(log(sobrev))
  return(-ll)
}

s.hat <- function(theta.hat,dados){
  t=dados[,1]
  d=dados[,2]
  x1=dados[,3]
  lambda <- theta.hat[1]
  alpha <- theta.hat[2]
  beta1 <- theta.hat[3]
  sobrev = ((1+exp(beta1*x1))/(1+exp(alpha*t+beta1*x1)))^(lambda/alpha)
  return(sobrev)
}

residual.GTDL <- function(theta.hat,dados){
  
  dados <- as.data.frame(dados)
  dados$s.hat <- s.hat(theta.hat=theta.hat,dados=dados)
  colnames(dados) <- c("t","status","x1","s.hat")
  
  # Resíduos
  #------------------
  # Cox-Snell
  rCS <- -log(dados$s.hat)
  #------------------
  # Cox-Snell Modificada - [-log(0.5)=0.693]
  csm.0 <- dplyr::filter(dados,status==0)
  csm.1 <- dplyr::filter(dados,status==1)  
  CSm.1 <- -log(csm.1$s.hat)
  CSm.0 <- -log(csm.0$s.hat)-log(0.5)
  rCSm <- c(CSm.1,CSm.0)
  #------------------
  #-Resíduos Martingale
  rM <- (dados$status-rCS)
  #------------------
  #-Resíduos Deviance
  rDev<-sign(rM)*sqrt(-2*(rM+dados$status*log(dados$status-rM)))
  #------------------
  # NMSP
  c.0 <- dplyr::filter(dados,status==0)
  c.1 <- dplyr::filter(dados,status==1)  
  USP.1 <- c.1$s.hat
  USP.0 <- (0.368)*c.0$s.hat
  rNMSP <- c(USP.1,USP.0)
  #------------------
  # NRSP
  R.1 <- c.1$s.hat
  R.0 <- runif(length(c.0$s.hat),0,1)*c.0$s.hat
  rNRSP <- c(R.1,R.0)
  #------------------
  # Resíduos Quant?licos
  rQuant <- dados[,2]* (1 - dados$s.hat) + (1-dados[,2])*runif(n,1-dados$s.hat)
  
  # Results
  results <- list()
  results$rCS <- rCS
  results$rCSm <- rCSm
  results$rM <- rM
  results$rDev <- rDev
  results$NMSP <- qnorm(rNMSP)
  results$NRSP <- qnorm(rNRSP)
  results$rQuant <- qnorm(rQuant)
  return(results)
}

medidas <- function(x){
  f1 <- basicStats(x)
  f2 <- c(f1[7,],f1[8,],f1[14:16,])
  return(f2)
}

simula.residual <- function(R,n,para,x1,m){
  
  mCS <- matrix(NA,nrow=n,ncol=R)
  mCSm <- matrix(NA,nrow=n,ncol=R)
  mM <- matrix(NA,nrow=n,ncol=R)
  mDev <- matrix(NA,nrow=n,ncol=R)
  mNMSP <- matrix(NA,nrow=n,ncol=R)
  mNRSP <- matrix(NA,nrow=n,ncol=R)
  mTheta <- matrix(NA,nrow=R,ncol=length(para))
  mQuant <- matrix(NA,nrow=n,ncol=R)
  i <- 1
  while (i<(R+1)) {
    amostra <- rGTDL(n=n,para=para, x1=x1,m=m)
    chute <- list(lambda=para[1],alpha=para[2],beta1=para[3])
    model <- try(mle2(l.GTDL, start=chute ,data=list(dados=amostra)
                      ,method="BFGS"),silent = T)
    
    if(!class(model)=="try-error"){
      
      mTheta[i,] <- coef(model)
      r <- residual.GTDL(theta.hat=coef(model),dados=amostra)
      
      if(any(is.na(r$rDev))==FALSE){
        mCS[,i]<- sort(r$rCS)
        mCSm[,i]<- sort(r$rCSm)
        mM[,i]<- sort(r$rM)
        mDev[,i]<- sort(r$rDev)
        mNMSP[,i] <- sort(r$NMSP)
        mNRSP[,i] <- sort(r$NRSP)
        mQuant[,i] <- sort(r$rQuant)
        i <- i+1
      }
    }
  }
  result <- list()
  result$med.CS <- apply(mCS,1,mean)
  result$med.CSm <- apply(mCSm,1,mean)
  result$med.M <- apply(mM,1,mean)
  result$med.Dev <- apply(mDev,1,mean)
  result$med.NMSP <- apply(mNMSP,1,mean)
  result$med.NRSP <- apply(mNRSP,1,mean)
  result$med.Quant <- apply(mQuant,1,mean)
  #result$mTheta <- mTheta
  #colnames(result$mTheta)<-c("alpha","lambda","beta")
  stat.CS <- medidas(apply(mCS,1,mean))
  stat.CSm <- medidas(apply(mCSm,1,mean))
  stat.M <- medidas(apply(mM,1,mean))
  stat.Dev <- medidas(apply(mDev,1,mean))
  stat.NMSP <- medidas(apply(mNMSP,1,mean))
  stat.NRSP <- medidas(apply(mNRSP,1,mean))
  stat.Quant <- medidas(apply(mQuant,1,mean))
  
  result$stat <- matrix(c(stat.CS,stat.CSm,stat.M,stat.Dev,stat.NMSP,stat.NRSP,stat.Quant),ncol=5,byrow=TRUE)
  colnames(result$stat)<-c("Mean","Median","Stdev","Skewness","Kurtosis")
  return(result)
}
